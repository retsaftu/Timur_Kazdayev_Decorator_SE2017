package com.company;

public interface BurgerComposition {

    public String getName();

    public double getPrice();

    public double getCalorieContent();
}
