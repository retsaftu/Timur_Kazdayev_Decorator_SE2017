I used the decorator pattern for the example of creating a burger from different parts 
(like cutlet, cheese, pastry, and so on)